﻿# watershed-Segmentation
example1：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_1.png)  
example2：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_2.png)  
example3：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_3.png)  
example4：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_4.png)  
example5：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_5.png)  
example6：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_6.png)  
example7：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_7.png)  
example8：  
![图片](https://github.com/102757017/watershed/blob/master/result/figure_8.png)  