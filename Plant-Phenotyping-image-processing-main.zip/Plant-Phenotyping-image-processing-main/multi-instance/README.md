# It can be run by:
#       python3 train.py (folder_name) or python3 deepcolor.py
# It will compute segmentation results and show symmetric best dice score.
